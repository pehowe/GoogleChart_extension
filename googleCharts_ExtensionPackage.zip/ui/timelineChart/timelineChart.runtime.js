﻿(function () {

	TW.Runtime.Widgets.timelineChart = function () {
        var thisWidget = this; 
		var currentlySelectedRow = undefined;
		
		this.runtimeProperties = function () {
			return {
				'needsDataLoadingAndError': true,
				'supportsAutoResize': true,
			'propertyAttributes': {
				}
			};
		};

		this.renderHtml = function () {
		if (this.properties.ResponsiveLayout === true ) {
			widgetWidth = '100%';
			widgetHeight = '100%';
		} else {
			widgetWidth = this.getProperty("Width");
			widgetHeight = this.getProperty("Height");
		}
			var html = '<div class="widget-content widget-timelineChart"><div id = "chart_div" width=' + widgetWidth + ' height=' + widgetHeight + '> </div></div>';
			return html;
		};
		
		this.loadChart = function (rows, RowLabel, BarLabel, startDate, endDate ) {
			 google.charts.load('current', {'packages':['timeline']});
			 google.charts.setOnLoadCallback(drawChart);
             
			 function drawChart() {
				var data = new google.visualization.DataTable();
				data.addColumn('string', 'RowLabel');
				data.addColumn('string', 'BarLabel');
				data.addColumn('date', 'startDate');
				data.addColumn('date', 'endDate');
		 
				for (var i = 0; i < rows.length; i++) {
					var row = rows[i];

					data.addRows([
						[row[RowLabel], row[BarLabel], new Date(row[startDate]), new Date(row[endDate])]
					]);
				}

			 var barHeight = thisWidget.getProperty('ItemHeight');
			 var chartHeight = rows.length *  barHeight + 50; 
			 var itemHeight = barHeight - 5;
			 var colorByRowLabel = thisWidget.getProperty('ColorByRowLabel');
			 var groupByRowLabel = thisWidget.getProperty('GroupByRowLabel');
			 var avoidOverlappingGridLines = thisWidget.getProperty('AvoidOverlappingGridLines');
			 var backgroundColor = TW.getStyleFromStyleDefinition(thisWidget.getProperty('BackgroundColor', 'DefaultTimelineBackgroundStyle')); 
			 var showBarLabels = thisWidget.getProperty('ShowBarLabels');
			 var showRowLabels = thisWidget.getProperty('ShowRowLabels');
			 var enabledCustomBarColors = thisWidget.getProperty('EnableCustomBarColors');
			 var numberOfBarColors = thisWidget.getProperty('NumberOfBarColors');
			 
			 var timelineBackground = backgroundColor.backgroundColor;
			//console.log("background:"+timelineBackground);
		
			// Get color array 
			var barColorList = [];
			for(var i=1; i<=numberOfBarColors;i++) {
				var seriesBarColorName = 'SeriesBarColorStyle' + i;
				var seriesBarColorStyleName = 'DefaultTimelineBarColorStyle'+i;
				var singleColor = TW.getStyleFromStyleDefinition(thisWidget.getProperty(seriesBarColorName, seriesBarColorStyleName)); 
				//if (i > 1 && i <= numberOfBarColors) {
				//	barColorList +=  ",";
				//}
				var colorForeground = singleColor.secondaryBackgroundColor;
				//console.log("style:" + seriesBarColorName + "style name: "+seriesBarColorStyleName);
				//console.log("colorForeground : " + colorForeground);
				//var indexOpen = colorForeground.indexOf("(") + 1; // Skip the (
				//var indexClose = colorForeground.indexOf(")");
				//var colorValueList = colorForeground.substr(indexOpen, indexClose-indexOpen);
				//var colorValues = colorValueList.split(",");
				//console.log("values:"+indexOpen+" : " + indexClose + " : " + colorValueList + " : " + colorValues);
				var hexColor = "#";
				//console.log("HexStart:" + colorValueList);
				//for (j = 0;j<colorValues.length-1;j++) {
				//	console.log("J:"+j+" :"+ colorValues[j]);
				//	hexColor += Number(colorValues[j]).toString(16);
				//}
				
				
				
				//console.log("SingleColor:"+colorForeground);
				//barColorList.push(colorForeground);
				barColorList.push(colorForeground);
			}
			//barColorList += "]";
			//console.log(" bar:" + barColorList.toString());

			// var customColorString = "";
			// if (enabledCustomBarColors == true) {
			//	customColorString = "colors: " + barColorList;
			//  }
			
			//console.log(" colorlist: "+barColorList);
			 // var options = {
			//	  width: "100%",
			//	  avoidOverlappingGridLines: avoidOverlappingGridLines,
			//	  backgroundColor: timelineBackground,
			//	  colors: ['green','yellow','red'],
			//	  timeline: { 
			//		  barHeight: itemHeight,
			//		  trackHeight: barHeight,
			//		   colorByRowLabel: colorByRowLabel,
			//		   groupByRowLabel: groupByRowLabel,
			//		   showRowLabels: showRowLabels,
			//		   showBarLabels: showBarLabels
			//		}
			//	};

			var options;
			if (enabledCustomBarColors == true) {
			  options = {
				  width: "100%",
				  avoidOverlappingGridLines: avoidOverlappingGridLines,
				  backgroundColor: timelineBackground,
				  colors: barColorList,
				  timeline: { 
					  barHeight: itemHeight,
					  trackHeight: barHeight,
					   colorByRowLabel: colorByRowLabel,
					   groupByRowLabel: groupByRowLabel,
					   showRowLabels: showRowLabels,
					   showBarLabels: showBarLabels
					}
				};
				console.log("enabled:"+options);
				console.log(JSON.stringify(options));
				//console.log("length:"+options.length);
				//for (var i=0;i<options.length;i++){
				//	console.log("i:"+i+" opt:"+options[i]);
				//}
			} else {
			  options = {
				  width: "100%",
				  avoidOverlappingGridLines: avoidOverlappingGridLines,
				  backgroundColor: timelineBackground,
				  timeline: { 
					  barHeight: itemHeight,
					  trackHeight: barHeight,
					   colorByRowLabel: colorByRowLabel,
					   groupByRowLabel: groupByRowLabel,
					   showRowLabels: showRowLabels,
					   showBarLabels: showBarLabels
					}
				}
				console.log("NOT enabled:"+options);
				console.log(JSON.stringify(options));
				//console.log("length:"+options.length);
				//for (var i=0;i<options.length;i++){
				//	console.log("i:"+i+" opt:"+options[i]);
				//}
			};
			
			var optionsSize = options.length;
			for (var k = 0; k<optionsSize; k++) {
				console.log ("k:"+k+" value: "+options[k]);
			}
			//var dispOptions = options.toString();
			console.log(" options2: "+options);
			console.log(JSON.stringify(options));
				
				var chart = new google.visualization.Timeline(document.getElementById('chart_div'));

				chart.draw(data, options);
 
				google.visualization.events.addListener(chart, 'select', function(e) {
					var selection = chart.getSelection(); 
					if (selection[0] != undefined && selection[0] != null) 
						thisWidget.handleRowSelection (selection[0].row);
				});
	
			 }
		};

		this.afterRender = function () { };


		this.handleSelectionUpdate = function (propertyName, selectedRows, selectedRowIndices) {
			var domElementId = this.jqElementId;
			var widgetElement = this.jqElement;
			var widgetProperties = this.properties;

			if (propertyName == "Data") {
				var widgetProperties = this.properties;

				var idField = widgetProperties['RowLabel'];

				thisWidget.ignoreSelectionEvent = true;

				var nSelectedRows = selectedRows.length;

				if (nSelectedRows > 0) {
					for (var x = 0; x < nSelectedRows; x++) {
						if (selectedRows[x]._isSelected === true) {
							thisWidget.handleRowSelection(selectedRows[x]["_row_"]);
							thisWidget.ignoreSelectionEvent = false;
							break;
						}
					}
				} else
					thisWidget.handleRowSelection(undefined);

				thisWidget.ignoreSelectionEvent = false;
			}

		};

		this.handleRowSelection = function (selectedRowNo) {
			if (selectedRowNo !== undefined) {
				var selectedRows = [selectedRowNo];

				if (!thisWidget.ignoreSelectionEvent) {
					thisWidget.updateSelection('Data', selectedRows);
				}
			}

			thisWidget.currentlySelectedRow = selectedRowNo;
		};
		
	    this.handleItemClick = function (d) {
			thisWidget.handleRowSelection(d["_row_"]);
		};
		
	    this.assignRowNumbers = function (rows) {
			var rowid;

			for (rowid in rows) {
				var row = rows[rowid];
				row["_row_"] = rowid;
			}
		};

		this.updateProperty = function (updatePropertyInfo) {
			var widgetProperties = this.properties;

			if (updatePropertyInfo.TargetProperty === "Data") {
				thisWidget.lastData = updatePropertyInfo;

				var rows = updatePropertyInfo.ActualDataRows;

				this.assignRowNumbers(rows);
	
				var rowLabel = widgetProperties['RowLabel'];
				var barLabel = widgetProperties['BarLabel'];
				var startDate = widgetProperties['StartDate'];
				var endDate = widgetProperties['EndDate'];
 
				this.loadChart(rows, rowLabel, barLabel, startDate, endDate);

				var selectedRowIndices = updatePropertyInfo.SelectedRowIndices;

				if (selectedRowIndices !== undefined) {
					if (selectedRowIndices.length > 0) {
						var selectedRows = new Array();
						selectedRows.push(rows[selectedRowIndices[0]]);
						setTimeout(function () {
							thisWidget.handleSelectionUpdate("Data", selectedRows, selectedRowIndices);
						}, 100);
					} else {
						setTimeout(function () {
							thisWidget.handleSelectionUpdate("Data", [], []);
						}, 100);
					}
				} else {
					setTimeout(function () {
						thisWidget.handleSelectionUpdate("Data", [], []);
					}, 100);
				}

				if (this.SelectedValuePending !== undefined) {
					this.selectItem(this.SelectedValuePending);
					this.SelectedValuePending = undefined;
				}

			} else if (updatePropertyInfo.TargetProperty === "SelectedValue") {
				var selectedItem = updatePropertyInfo.SinglePropertyValue;

				var dataPropertyInfo = thisWidget.lastData;

				if (dataPropertyInfo != undefined) {
					this.selectItem(selectedItem);
				} else {
					this.SelectedValuePending = selectedItem;
				}
			}
		};

		this.beforeDestroy = function () {

		};
		this.resize =  function () {

			var rowLabel = thisWidget.getProperty('RowLabel');
			var barLabel = thisWidget.getProperty('BarLabel');
			var startDate = thisWidget.getProperty('StartDate');
			var endDate = thisWidget.getProperty('EndDate');
			var itemHeight = thisWidget.getProperty("ItemHeight");
		    var rows = thisWidget.lastData.ActualDataRows;
		 
			thisWidget.loadChart(rows, rowLabel, barLabel, startDate, endDate); 
		};
		window.addEventListener("resize", this.resize);
	};
}
	());
