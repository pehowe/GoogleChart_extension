﻿/* global Encoder, TW */
TW.IDE.Widgets.timelineChart = function () {
	
	// Max for number of colors
	this.MAX_COLORS = 8;
	this.widgetIconUrl = function() {
		return "../Common/extensions/googleCharts_ExtensionPackage/ui/timelineChart/timelineChart.ide.png";
	};

	this.widgetProperties = function () {
		var properties = {
			'name': 'TimeLine Chart',
			'description': 'An Time Line Chart widget.',
			'category': ['Data'],
            'defaultBindingTargetProperty': 'Data',
            'supportsAutoResize': true,	
			'properties': {
                'RowLabel': {
                    'description': 'Field to Label Row',
                    'baseType': 'FIELDNAME',
                    'sourcePropertyName': 'Data'
                },
			    'BarLabel': {
                    'description': 'Field with bar label',
                    'baseType': 'FIELDNAME',
                    'sourcePropertyName': 'Data'
                },
				'StartDate': {
                    'description': 'Field to use for start date',
                    'baseType': 'FIELDNAME',
                    'sourcePropertyName': 'Data'
                },
				'EndDate': {
                    'description': 'Field to use for end date',
                    'baseType': 'FIELDNAME',
                    'sourcePropertyName': 'Data'
                },
                'Data': {
                    'description': 'Data source',
                    'isBindingTarget': true,
                    'isEditable': false,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': true
                },
				'ItemHeight': {
                    'description': 'Field to use for the element height',
                    'baseType': 'NUMBER',
                    'defaultValue': 23, 
					'isBindingTarget': false
                },
				'EnableCustomBarColors': {
					'description': 'Google Chart will auto select color',
					'baseType': 'BOOLEAN',
					'defaultValue': false,
					'isBindingTarget': false,
					'isVisible': true 
				},
				'NumberOfBarColors': {
					'description': 'How many different bar colors are allowed to be configured.',
					'defaultValue': 5,
					'baseType': 'NUMBER',
					'isVisible': true
				},
				// True/False custom colors
				// If true number for number of colors
				// BarStyle
				'AvoidOverlappingGridLines': {
                    'description': 'Whether display elements(e.g., the bars in a timeline) should obscure grid lines. If false, grid lines may be covered completley by display elements.',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true,
					'isBindingTarget': false,
					'isVisible': true
                },
				'BackgroundColor': {
					'description': 'The background color fosthe main area of the chart. Can be either a simple HTML color string, for example: red or #00cc00.',
					'baseType':'STYLEDEFINITION',
					'defaultValue': 'DefaultTimelineBackgroundStyle',
					'isVisible': true
				},
				'ColorByRowLabel': {
                    'description': 'If set to true, color every bar on the row the same.',
                    'baseType': 'BOOLEAN',
                    'defaultValue': false,
					'isBindingTarget': false,
					'isVisible': true
                },
				'GroupByRowLabel': {
                    'description': 'If set to false, creates one row for each dataTable entry.',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true,
					'isBindingTarget': false,
					'isVisible': true
                },
				'ShowBarLabels': {
                    'description': 'If set to false, omits bar labels. The default is to show them.',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true,
					'isBindingTarget': false,
					'isVisible': true
                },				
				'ShowRowLabels': {
                    'description': 'If set to false, omits row labels. The default is to show them.',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true,
					'isBindingTarget': false,
					'isVisible': true
                } 
			}
		};
		
		var seriesNumber;
		for (seriesNumber = 1; seriesNumber <= this.MAX_COLORS; seriesNumber++) {
			var seriesBarColorProperty = {
				'description': 'Color for bar ' + seriesNumber,
				'baseType': 'STYLEDEFINITION',
				'isVisible': false
			}
			properties.properties['SeriesBarColorStyle' + seriesNumber] = seriesBarColorProperty;
			properties.properties['SeriesBarColorStyle' + seriesNumber]['defaultValue'] = 'DefaultTimelineBarColorStyle' + seriesNumber;
		}
		
		return properties;
	};

    this.setSeriesProperties = function (value) {
        var allWidgetProps = this.allWidgetProperties();
		//console.log("setSeriesProperties");
		if (this.getProperty('EnableCustomBarColors') == true) {
			//console.log("Value="+value);
			if (value > 0) {
				var seriesNumber;
				for (seriesNumber = 1; seriesNumber <= value; seriesNumber++) {
					allWidgetProps['properties']['SeriesBarColorStyle' + seriesNumber]['isVisible'] = true;
					//console.log("seriesNumber Vis="+seriesNumber);
				}
				for (seriesNumber = value + 1; seriesNumber <= this.MAX_COLORS; seriesNumber++) {
					allWidgetProps['properties']['SeriesBarColorStyle' + seriesNumber]['isVisible'] = false;
					//console.log("seriesNumber Not="+seriesNumber);
				}
			}
		} else {
			console.log(" Other :"+value);
			var seriesNumber;
			for (seriesNumber = 1; seriesNumber <= this.MAX_COLORS; seriesNumber++) {
				var colorBarName = 'SeriesBarColorStyle' + seriesNumber;
				allWidgetProps['properties'][colorBarName]['isVisible'] = false;
			}
		}
        allWidgetProps['properties']['Data']['isVisible'] = true;
		this.updatedProperties();
    };

    this.widgetEvents = function () {
        return {
        	'DoubleClicked': {}, 
        };
    };

	this.renderHtml = function () {
        var html = '';
        html += '<div class="widget-content widget-timelineChart">'
			 +  '<table height="100%" width="100%"><tr><td valign="middle" align="center">'
			 +  '<span>Timeline Chart</span></td></tr></table></div>';
        return html;
	};

    this.afterRender = function () {
       // this property can't be hidden in setProperties because ResponsiveLayout is still undefined in most cases
       // this.allWidgetProperties()['properties']['ShowZoomStrip']['isVisible'] = !this.properties.ResponsiveLayout;
        this.updatedProperties();
    };

    this.afterLoad = function () {
		var allWidgetProps = this.allWidgetProperties();
        this.setSeriesProperties(this.getProperty('NumberOfBarColors'));
			var isEnabledCustom = this.getProperty('EnableCustomBarColors');
			if (isEnabledCustom === true) {
				this.allWidgetProperties()['properties']['NumberOfBarColors']['isVisible'] = true;
			} else {
				this.allWidgetProperties()['properties']['NumberOfBarColors']['isVisible'] = false;
			}
        //this.setSeriesAxisProperties(this.getProperty('NumberOfSeries'));
    };

	this.afterSetProperty = function (name, value) {
		if (name === 'RowLabel' ||
			name === 'BarLabel' ||
			name === 'StartDate' ||
			name === 'EndDate' ||
			name === 'ItemHeight') {
			return true;
		}
		if (name === 'NumberOfBarColors') {
			this.setSeriesProperties(this.getProperty('NumberOfBarColors'));
			
			return true;
		}
		if (name === 'EnableCustomBarColors') {
			var isEnabledCustom = this.getProperty('EnableCustomBarColors');
			if (isEnabledCustom === true) {
				this.allWidgetProperties()['properties']['NumberOfBarColors']['isVisible'] = true;
				this.setSeriesProperties(this.getProperty('NumberOfBarColors'));
			} else {
				this.allWidgetProperties()['properties']['NumberOfBarColors']['isVisible'] = false;
				this.setSeriesProperties(this.getProperty('NumberOfBarColors'));
			}
			this.updatedProperties();
			return true;
		}
	};
	
	this.beforeSetProperty = function (name, value) {
		// first function called on a drop into mashup
		this.setSeriesProperties(this.getProperty('NumberOfBarColors'));
		if (name === 'NumberOfBarColors') {
			value = parseInt(value, 10);
			if (value <= 0 || value > this.MAX_COLORS) {
				return "Number of Bar Colors Must be between 1 and " + this.MAX_COLORS;
			}
		}
	};

    this.validate = function () {
        var result = [];

       if (this.isPropertyBoundAsTarget('Data')) {
            if (this.getProperty('RowLabel') === undefined || this.getProperty('RowLabel').length === 0) {
                result.push({ severity: 'warning', message: 'RowLabel for {target-id} must be chosen' });
            }
            if (this.getProperty('BarLabel') === undefined || this.getProperty('BarLabel').length === 0) {
                result.push({ severity: 'warning', message: 'BarLabel for {target-id} must be chosen' });
            }
			if (this.getProperty('StartDate') === undefined || this.getProperty('StartDate').length === 0) {
                result.push({ severity: 'warning', message: 'StartDate for {target-id} must be chosen' });
            }
			if (this.getProperty('EndDate') === undefined || this.getProperty('EndDate').length === 0) {
                result.push({ severity: 'warning', message: 'EndDate for {target-id} must be chosen' });
            }
        } 

        return result;
    };
};